<?php
class C_login extends CI_Controller
{
    public function index()
    {
        $this->load->view('dist/auth-login');
    }
}
